package com.mindtree.orchardcampusmind;

import java.util.Scanner;

public class CampusMindApplication {
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		boolean isContinue = true;
		System.out.println("Enter the number of campus minds in orchard");
		int noOfCampusMinds = scan.nextInt();

		CampusMind[] campusMinds = new CampusMind[noOfCampusMinds];

		do {
			int choice = displayMenu();
			switch (choice) {
			case 1:
				getCreatedCampusMinds(campusMinds);
				break;
			case 2:
				CampusMind[] sorted = getSortedByCapabilitiesCleared(campusMinds);
				displayAllCampusMinds(sorted);
				break;
			case 3:
				updateTotalCapabilitiesCount(campusMinds);
				System.out.println("====================");
				displayAllCampusMinds(campusMinds);
				break;
			case 4:
				int position = searchCampusMind(campusMinds);
				System.out.println("The current status of campusMind at " + position + " is : ");
				// System.out.println("Cleared " +
				// campusMinds[position].getCapabilitiesCleared() + " capabilities");
				System.out.println("=====================");
				break;
			case 5:
				isContinue = false;
				System.out.println("Out of App");
				break;
			default:
				System.out.println("Enter a valid choice");
				break;
			}

		} while (isContinue);

	}

	/*
	 * private static void searchCampusMind(CampusMind[] campusMinds) {
	 * 
	 * boolean flag = false;
	 * System.out.println("Enter id of a campusmind to be serached"); String
	 * searchId = scan.next(); for (int i = 0; i < campusMinds.length; i++) { if
	 * (searchId.compareTo(campusMinds[i].getId()) == 0) {
	 * System.out.println("The current status of campus mind is: ");
	 * System.out.println("Cleared " + campusMinds[i].getCapabilitiesCleared() +
	 * " capabilities"); flag = true; break; } } if (flag == false) {
	 * System.out.println("CampusMind not found"); }
	 * 
	 * }
	 */
	private static int searchCampusMind(CampusMind[] campusMinds) {
		getSortedByCapabilitiesCleared(campusMinds);
		System.out.println("Enter id of a campusmind to be serached");
		String searchId = scan.next();
		int low = 0;
		int high = campusMinds.length - 1;
		int mid = 0;
		while (low <= high) {
			mid = (low + high) / 2;
			if (campusMinds[mid].getId().compareTo(searchId) == 0) {
				return mid;
			} else if (campusMinds[mid].getId().compareTo(searchId) > 0)
				high = mid - 1;
			else
				low = mid + 1;
		}
		return -1;

	}

	public static CampusMind[] getSortedByCapabilitiesCleared(CampusMind[] campusMinds) {
		for (int i = 0; i < campusMinds.length - 1; i++) {
			for (int j = 0; j < campusMinds.length - 1 - i; j++) {
				// if (campusMinds[i].getCapabilitiesCleared() !=
				// campusMinds[j].getCapabilitiesCleared()) {
				if (campusMinds[j].getCapabilitiesCleared() > campusMinds[j + 1].getCapabilitiesCleared()) {
					CampusMind temp = campusMinds[j];
					campusMinds[j] = campusMinds[j + 1];
					campusMinds[j + 1] = temp;
				}
			}
		}
		return campusMinds;
	}
	/*
	 * else { // for (int index = 0; index < campusMinds.length; index++) { // for
	 * (int jindex = index + 1; jindex < campusMinds.length; jindex++) { if
	 * (campusMinds[i].getTrackName().compareTo(campusMinds[j].getTrackName()) > 0)
	 * { CampusMind temp = campusMinds[i]; campusMinds[i] = campusMinds[j];
	 * campusMinds[j] = temp; } } } } // } // }
	 */

	private static CampusMind[] updateTotalCapabilitiesCount(CampusMind[] campusMinds) {
		System.out.println("Enter track of a  campus mind");
		String trackName = scan.next();
		for (int i = 0; i < campusMinds.length; i++) {
			if (trackName.compareTo(campusMinds[i].getTrackName()) == 0) {
				scan.nextLine();
				System.out.println("Enter new capabilities count ");
				int newCount = scan.nextInt();
				campusMinds[i].setCapabilitiesCount(newCount);
				System.out.println("The updated capabilities of campus mind is " + newCount);

			}
		}
		return campusMinds;
	}

	private static void getCreatedCampusMinds(CampusMind[] campusMinds) {
		for (int i = 0; i < campusMinds.length; i++) {
			System.out.println("Enter Mid of campus mind");
			String id = scan.next();
			scan.nextLine();

			System.out.println("Enter name of campus mind");
			String name = scan.nextLine();

			System.out.println("Enter track of campus mind");
			String trackName = scan.nextLine();

			System.out.println("Enter capabilitiesCount  of a campus mind");
			int capabilitiesCount = scan.nextInt();

			System.out.println("Enter capabilities cleared of campus mind");
			int capabilitiesCleared = scan.nextInt();

			campusMinds[i] = new CampusMind(id, name, trackName, capabilitiesCount, capabilitiesCleared);
		}

	}

	private static void displayAllCampusMinds(CampusMind[] campusMinds) {
		System.out.println("The details of Campusminds are:");
		for (int i = 0; i < campusMinds.length; i++) {
			System.out.println(" " + campusMinds[i].getId());
			System.out.println(" " + campusMinds[i].getName());
			System.out.println(" " + campusMinds[i].getTrackName());
			System.out.println(" " + campusMinds[i].getCapabilitiesCount());
			System.out.println(" " + campusMinds[i].getCapabilitiesCleared());
			System.out.println("========================");
		}

	}

	private static int displayMenu() {
		System.out.println("Enter your choice");
		System.out.println("1.Enter details of the campusmind");
		System.out.println("2.Display as per sorted by  capabilities cleared, if same then display as per trackname");
		System.out.println("3.Update the total capabilities count for a track");
		System.out.println("4.Search for campus mind and display the current status of capabilities of campus mind");
		System.out.println("5.Exit");
		int choice = scan.nextInt();
		return choice;

	}
}
