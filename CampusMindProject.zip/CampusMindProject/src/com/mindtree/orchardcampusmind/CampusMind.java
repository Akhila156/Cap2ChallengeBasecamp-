package com.mindtree.orchardcampusmind;

public class CampusMind {
	private String id;
	private String name;
	private String trackName;
	private int capabilitiesCount;
	private int capabilitiesCleared;

	public CampusMind() {
		super();

	}

	public CampusMind(String id, String name, String trackName, int capabilitiesCount, int capabilitiesCleared) {
		super();
		this.id = id;
		this.name = name;
		this.trackName = trackName;
		this.capabilitiesCount = capabilitiesCount;
		this.capabilitiesCleared = capabilitiesCleared;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTrackName() {
		return trackName;
	}

	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}

	public int getCapabilitiesCount() {
		return capabilitiesCount;
	}

	public void setCapabilitiesCount(int capabilitiesCount) {
		this.capabilitiesCount = capabilitiesCount;
	}

	public int getCapabilitiesCleared() {
		return capabilitiesCleared;
	}

	public void setCapabilitiesCleared(int capabilitiesCleared) {
		this.capabilitiesCleared = capabilitiesCleared;
	}

}
